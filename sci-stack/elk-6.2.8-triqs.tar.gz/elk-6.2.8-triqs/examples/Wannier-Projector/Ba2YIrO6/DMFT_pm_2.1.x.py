import os,sys,inspect
sys.path.insert(1, os.path.join(sys.path[0], '../../../../../'))
from triqs_dft_tools.sumk_dft import *
from triqs_dft_tools.trans_basis import *
from pytriqs.gf import *
import numpy as np
from triqs_cthyb import *
import sys


from pytriqs.operators.util.U_matrix import *
from pytriqs.operators.util import *
from pytriqs.operators import *

import pytriqs.utility.mpi as mpi
from pytriqs.archive import HDFArchive

#Script written by Hermann Schnait

filename = 'Ba2YIrO6'


# Setup CTQMC Solver
beta = 40.0
U = 2.0
J = 0.3

# Double Counting: 0 FLL, 1 Held, 2 AMF
DC_type = 0


interesting_indices_no = [2,3,4,7,8,9]


n_iterations = 20


# Parameters for the CTQMC Solver
p = {}
p["max_time"] = -1
p["random_name"] = ""
p["random_seed"] = 255 * mpi.rank + 748

p["length_cycle"] = 100
p["n_warmup_cycles"] =  100000
p["n_cycles"] =   2500000 

p["move_double"] = True


fit_expansion_order = 4
fit_n_min = 30
fit_n_max = 60
fit_n_tail_max = 200


MIXING = 0.3 


#adnj edit - read in dft stuff
from triqs_dft_tools.converters.elk_converter import *
Converter = ElkConverter(filename=filename, repacking=True)
Converter.convert_dft_input()



SK = SumkDFT(hdf_file = filename+'.h5',use_dft_blocks = True)
mpi.report(SK.block_structure)
SK.block_structure.pick_gf_struct_sumk([{'ud':interesting_indices_no}])
mpi.report(SK.block_structure)


S = Solver(beta=beta, gf_struct=SK.block_structure.gf_struct_solver_list[0]) # apparently the solver needs this in form of a list...


### MPI STUFF ###
iteration_offset = 0
last_Sigma = 0 # for mixing
if mpi.is_master_node():
    ar = HDFArchive(filename+'.h5','a')
    if not 'DMFT_results' in ar: ar.create_group('DMFT_results')
    if not 'Iterations' in ar['DMFT_results']: ar['DMFT_results'].create_group('Iterations')
    if 'iteration_count' in ar['DMFT_results']:
        iteration_offset = ar['DMFT_results']['iteration_count']+1
        S.Sigma_iw = ar['DMFT_results']['Iterations']['Sigma_it'+str(iteration_offset-1)]
        last_Sigma = S.Sigma_iw.copy()
        SK.dc_imp = ar['DMFT_results']['Iterations']['dc_imp'+str(iteration_offset-1)]
        SK.dc_energ = ar['DMFT_results']['Iterations']['dc_energ'+str(iteration_offset-1)]
        SK.chemical_potential = ar['DMFT_results']['Iterations']['chemical_potential'+str(iteration_offset-1)]

        # load blockstructure
        SK.block_structure = SK.load(['block_structure'], 'DMFT_results')[0]

    # save version and script log to hdf file
    if not 'DMFT_log' in ar: ar.create_group('DMFT_log')
    from pytriqs.version import version
    ar['DMFT_log']['code_version_it'+str(iteration_offset)] = version
    ar['DMFT_log']['script_it'+str(iteration_offset)] = open(sys.argv[0]).read()


iteration_offset = mpi.bcast(iteration_offset)
S.Sigma_iw = mpi.bcast(S.Sigma_iw)
SK.dc_imp = mpi.bcast(SK.dc_imp)
SK.dc_energ = mpi.bcast(SK.dc_energ)
SK.chemical_potential = mpi.bcast(SK.chemical_potential)
last_Sigma = mpi.bcast(last_Sigma)

SK.block_structure = mpi.bcast(SK.block_structure) # maybe this is needed... just a guess...


# Initialize Sigma in SK
# As "transform_to_sumk_blocks=True", we can directly put the Solver GF

if iteration_offset == 0:
    # If first iteration: Zero
    SK.put_Sigma([SK.block_structure.create_gf(beta = beta, space='solver')])
else:
    # Else set from last iteration
    SK.put_Sigma([S.Sigma_iw])



SK.calc_mu()

S.G_iw << SK.extract_G_loc()[0]


if iteration_offset == 0:
    SK.analyse_deg_shells([S.G_iw])

    mpi.report('Analysing deg_shells')
    mpi.report(SK.deg_shells)



#Init the DC term and the self-energy if no previous iteration was found
if iteration_offset == 0:
    SK.calc_dc(S.G_iw.density(), U_interact=U, J_hund=J, orb=0, use_dc_formula=DC_type)

    # initialize sigma with DC value
    # it does not matter whether this is done in solver or sumk space, as it's just a unity matrix
    for name, gf in S.Sigma_iw:
        for ind in gf.indices[0]:
            gf[ind,ind] << SK.dc_imp[0]['ud'][interesting_indices_no[0],interesting_indices_no[0]]

# Diagonalizing Hloc
if iteration_offset == 0:
    mpi.report('Diagonalizing Hloc')

    #from triqs_dft_tools.trans_basis import TransBasis
    TB = TransBasis(SK)
    TB.calculate_diagonalisation_matrix(prop_to_be_diagonal='eal', calc_in_solver_blocks = True)

    # Unitary for eg orbitals
    for f in range(10):
        if f not in interesting_indices_no:
            TB.w[f,f] = 1

    SK.block_structure.transformation = [{'ud':TB.w.conjugate().transpose()}]
    #mpi.report('Transformation matrix:')
    #mpi.report(np.real(SK.block_structure.transformation))

    if mpi.is_master_node():
        ar['DMFT_results']['block_structure'] = SK.block_structure
        
    S.G_iw << SK.extract_G_loc()[0] # Extract Gloc again, now with basis trafo
else:
    mpi.report('Getting diagonalization matrix from h5 file.')
    #mpi.report(np.real(SK.block_structure.transformation))



mpi.report("Calculating new H_int\n")
### Set up H_int ###
U_sph = U_matrix(l=2, U_int=U, J_hund=J)
U_sph = np.kron(np.reshape(np.eye(2),(1,2,1,2)),np.kron(np.reshape(np.eye(2),(2,1,2,1)),U_sph))
U_cub = transform_U_matrix(U_sph, SK.T[0].conjugate())
U_trans = transform_U_matrix(U_cub, SK.block_structure.transformation[0]['ud'].conjugate()) # conjugate???
U_red = subarray(U_trans,len(U_trans.shape) * [interesting_indices_no])

H = h_int_slater(['ud'], interesting_indices_no, U_red, map_operator_structure=SK.block_structure.sumk_to_solver[0], off_diag=True, complex=True)


mpi.report('%s DMFT cycles requested. Starting with iteration %s.'%(n_iterations,iteration_offset))

# DMFT self consistency cycle
for it in range(iteration_offset, iteration_offset + n_iterations):
    mpi.report('Doing iteration: %s'%it)

    # Get G0
    S.G0_iw << inverse(S.Sigma_iw + inverse(S.G_iw))


    # maybe we need to force this...
    for block, gf in S.G0_iw:
        gf.data[:,:,:] = (gf.data[:,:,:] + gf.data[::-1].transpose([0,2,1]).conjugate())/2


    # solve impurity
    S.solve(h_int = H, **p)


    for block, gf in S.Sigma_iw:
        gf.data[:,:,:] = (gf.data[:,:,:] + gf.data[::-1].transpose([0,2,1]).conjugate())/2


    if mpi.is_master_node():
        ar['DMFT_results']['Iterations']['Sigma_preFit_it'+str(it)] = S.Sigma_iw
        ar['DMFT_results']['Iterations']['Sigma_raw_it'+str(it)] = S.Sigma_iw_raw
        ar['DMFT_results']['Iterations']['Gimp_it'+str(it)] = S.G_iw
        ar['DMFT_results']['Iterations']['Gtau_it'+str(it)] = S.G_tau
        ar['DMFT_results']['Iterations']['rho_it'+str(it)] = S.density_matrix
        ar['DMFT_results']['Iterations']['h_loc_diag_it'+str(it)] = S.h_loc_diagonalization
    mpi.report("Solver finished, starting to fit")
    #fit_tail(S.Sigma_iw)

    for name, gf in S.Sigma_iw:
        tail, error = gf.fit_hermitian_tail_on_window(n_min=fit_n_min, n_max=fit_n_max, n_tail_max=fit_n_tail_max, expansion_order=fit_expansion_order, known_moments=np.zeros((0,3,3))*1j)
        #gf.replace_tail_by_fit(tail, fit_n_min)
        gf = gf.replace_by_tail(tail, fit_n_min)

    if mpi.is_master_node():
        ar['DMFT_results']['Iterations']['Sigma_postFit_it'+str(it)] = S.Sigma_iw

    #adnj - This ensures that the off-diagonal elements are zero (for BS rotations) for the next loop.
    #Occasionally, off-diagonal elements of G_tau will be vastly non-zero causing
    #the calculation to crash. This will be seen in the above saved files
    for block in S.G_iw.indices:
      for i1, i2 in np.ndindex(3, 3):
        if(i1!=i2):
          S.Sigma_iw[block].data.imag[:,i1,i2]=0.0
          S.Sigma_iw[block].data.real[:,i1,i2]=0.0
          S.G_iw[block].data.imag[:,i1,i2]=0.0
          S.G_iw[block].data.real[:,i1,i2]=0.0



    if it >= 1 and MIXING > 0:
        S.Sigma_iw << MIXING * S.Sigma_iw + (1-MIXING) * last_Sigma
    last_Sigma = S.Sigma_iw.copy()

    SK.calc_dc(S.G_iw.density(), U_interact=U, J_hund=J, orb=0, use_dc_formula=DC_type)
    SK.put_Sigma([S.Sigma_iw])
    SK.calc_mu()

    S.G_iw << SK.extract_G_loc()[0]


    mpi.report('Total charge of Gloc : %.6f'%np.abs(S.G_iw.total_density()))

    if mpi.is_master_node():
        ar['DMFT_results']['iteration_count'] = it
        ar['DMFT_results']['Iterations']['Sigma_it'+str(it)] = S.Sigma_iw
        ar['DMFT_results']['Iterations']['Gloc_it'+str(it)] = S.G_iw
        ar['DMFT_results']['Iterations']['G0loc_it'+str(it)] = S.G0_iw
        ar['DMFT_results']['Iterations']['dc_imp'+str(it)] = SK.dc_imp
        ar['DMFT_results']['Iterations']['dc_energ'+str(it)] = SK.dc_energ
        ar['DMFT_results']['Iterations']['chemical_potential'+str(it)] = SK.chemical_potential

#adnj edit - output the density matrix for Elk interface
dN, d = SK.calc_density_correction_elk()

#correlation energy via the Migdal formula
correnerg = 0.5 * (S.G_iw * S.Sigma_iw).total_density()

#subtract the double counting energy
correnerg -= SK.dc_energ[0]
#convert to Hartree
correnerg = correnerg/SK.energy_unit

#save the correction to energy
if (mpi.is_master_node()):
  f=open('DMATDMFT.OUT','a')
  f.write("%.16f\n"%correnerg)
  f.close()


