from triqs_dft_tools.sumk_dft import *
#from triqs_dft_tools.sumk_dft.symmetry_orig import *
from triqs_dft_tools.trans_basis import *
from pytriqs.gf import *
import numpy as np
from triqs_cthyb import *
import sys


from pytriqs.operators.util.U_matrix import *
from pytriqs.operators.util import *
from pytriqs.operators import *

import pytriqs.utility.mpi as mpi
from pytriqs.archive import HDFArchive


filename = 'Ni'


# Setup CTQMC Solver
beta = 40.0
U = 2.0
J = 0.9
split_ini = 0.0 #used to split degeneracy in self-energy - not used for LSDA inputs

# Double Counting: 0 FLL, 1 Held, 2 AMF
DC_type = 2


n_iterations = 30


# Parameters for the CTQMC Solver
p = {}
p["max_time"] = -1
p["random_name"] = ""
p["random_seed"] = 252 * mpi.rank + 748

p["length_cycle"] = 100
p["n_warmup_cycles"] =  150000
p["n_cycles"] =   1500000 


fit_expansion_order = 4
fit_n_min = 50
fit_n_max = 90
fit_n_tail_max = 200

p["perform_tail_fit"] = True
p["fit_max_moment"] = fit_expansion_order
p["fit_min_n"] = fit_n_min
p["fit_max_n"] = fit_n_max

MIXING = 0.6
prec_mu = 0.000001
#adnj edit - read in dft stuff
from triqs_dft_tools.converters.elk_converter import *
Converter = ElkConverter(filename=filename, repacking=True)
Converter.convert_dft_input()


SK = SumkDFT(hdf_file = filename+'.h5',use_dft_blocks = True)
SK.analyse_block_structure(threshold=1e-02)
mpi.report(SK.block_structure)

mpi.report('U = %s, J = %s eV'%(U,J))
mpi.report('DC_type = %s'%(DC_type))
mpi.report('Beta = %s'%(beta))
mpi.report('MIXING = %s'%(MIXING))
mpi.report('Initial Split of Sigma = %s'%(split_ini))

S = Solver(beta=beta, gf_struct=SK.gf_struct_solver_list[0]) # apparently the solver needs this in form of a list...

### MPI STUFF ###
iteration_offset = 0
last_Sigma = 0 # for mixing
#read in variables
if mpi.is_master_node():
    ar = HDFArchive(filename+'.h5','a')
    if not 'DMFT_results' in ar: ar.create_group('DMFT_results')
    if not 'Iterations' in ar['DMFT_results']: ar['DMFT_results'].create_group('Iterations')
    if 'iteration_count' in ar['DMFT_results']:
        iteration_offset = ar['DMFT_results']['iteration_count']+1
        S.Sigma_iw = ar['DMFT_results']['Iterations']['Sigma_it'+str(iteration_offset-1)]
        last_Sigma = S.Sigma_iw.copy()
        SK.dc_imp = ar['DMFT_results']['Iterations']['dc_imp'+str(iteration_offset-1)]
        SK.dc_energ = ar['DMFT_results']['Iterations']['dc_energ'+str(iteration_offset-1)]
        SK.chemical_potential = ar['DMFT_results']['Iterations']['chemical_potential'+str(iteration_offset-1)]

    # save version and script log to hdf file
    if not 'DMFT_log' in ar: ar.create_group('DMFT_log')
    from pytriqs.version import version
    ar['DMFT_log']['code_version_it'+str(iteration_offset)] = version
    ar['DMFT_log']['script_it'+str(iteration_offset)] = open(sys.argv[0]).read()

#bcast read in variables
iteration_offset = mpi.bcast(iteration_offset)
S.Sigma_iw = mpi.bcast(S.Sigma_iw)
SK.dc_imp = mpi.bcast(SK.dc_imp)
SK.dc_energ = mpi.bcast(SK.dc_energ)
SK.chemical_potential = mpi.bcast(SK.chemical_potential)
last_Sigma = mpi.bcast(last_Sigma)


# Initialize Sigma in SK
SK.symm_deg_gf(S.Sigma_iw,ish=0) # symmetrise Sigma
SK.put_Sigma([S.Sigma_iw])

#calculate Gloc
SK.calc_mu(precision = prec_mu)
S.G_iw << SK.extract_G_loc()[0]

last_Giw = S.G_iw.copy()

spin_names = ["up","down"]
n_orb = SK.corr_shells[0]['dim']
orb_names = [i for i in range(n_orb)]
#Init the DC term and the self-energy if no previous iteration was found
if iteration_offset == 0:
    SK.calc_dc(S.G_iw.density(), U_interact=U, J_hund=J, orb=0, use_dc_formula=DC_type)
    # initialize sigma with DC value
    for i in range(n_orb): 
      S.Sigma_iw['up_%s'%i] << SK.dc_imp[0]['up'][0,0]+split_ini
      S.Sigma_iw['down_%s'%i] << SK.dc_imp[0]['down'][0,0]-split_ini

### Set up H_int ###
mpi.report("Calculating H_int\n")
U_sph = U_matrix(l=2, U_int=U, J_hund=J)
U_cubic = transform_U_matrix(U_sph, spherical_to_cubic(l=2, convention='wien2k'))
H = h_int_slater(spin_names, orb_names, U_matrix=U_cubic, map_operator_structure=SK.sumk_to_solver[0], H_dump="H.txt",off_diag=True)

#Degeneracy of orbitals
mpi.report('Orbital degeneracies:')
mpi.report(SK.deg_shells)
# DMFT self consistency cycle
mpi.report('%s DMFT cycles requested. Starting with iteration %s.'%(n_iterations,iteration_offset))
for it in range(iteration_offset, iteration_offset + n_iterations):
    mpi.report('Doing iteration: %s'%it)
    SK.symm_deg_gf(S.Sigma_iw,ish=0)  # symmetrise Sigma

    S.G0_iw << inverse(S.Sigma_iw + inverse(S.G_iw))

    # maybe we need to force this...
    for block, gf in S.G0_iw:
        gf.data[:,:,:] = (gf.data[:,:,:] + gf.data[::-1].transpose([0,2,1]).conjugate())/2

    # solve impurity
    S.solve(h_int = H, **p)

    for block, gf in S.Sigma_iw:
        gf.data[:,:,:] = (gf.data[:,:,:] + gf.data[::-1].transpose([0,2,1]).conjugate())/2

    #save parameters
    if mpi.is_master_node():
        ar['DMFT_results']['Iterations']['Sigma_raw_it'+str(it)] = S.Sigma_iw_raw
        ar['DMFT_results']['Iterations']['Gimp_it'+str(it)] = S.G_iw
        ar['DMFT_results']['Iterations']['Gtau_it'+str(it)] = S.G_tau
        ar['DMFT_results']['Iterations']['rho_it'+str(it)] = S.density_matrix
        ar['DMFT_results']['Iterations']['h_loc_diag_it'+str(it)] = S.h_loc_diagonalization
    mpi.report("Solver finished")

    #G_imp charge
    SK.symm_deg_gf(S.Sigma_iw,ish=0)  # symmetrise Sigma
    mpi.report('Total charge of Gimp : %.6f'%np.abs(S.G_iw.total_density()))

    #Mix sigma
    if it >= 1 and MIXING > 0:
        S.Sigma_iw << MIXING * S.Sigma_iw + (1-MIXING) * last_Sigma
        #Mix G_iw to stablize the calculation due to fluctuating DC
        S.G_iw << MIXING * S.G_iw + (1-MIXING) * last_Giw
    last_Sigma = S.Sigma_iw.copy()
    last_Giw = S.G_iw.copy()

    #New DC and G_loc
    SK.calc_dc(S.G_iw.density(), U_interact=U, J_hund=J, orb=0, use_dc_formula=DC_type)
    SK.put_Sigma([S.Sigma_iw])
    SK.calc_mu(precision = prec_mu)
    S.G_iw << SK.extract_G_loc()[0]
    mpi.report('Total charge of Gloc : %.6f'%np.abs(S.G_iw.total_density()))

    #save parameters
    if mpi.is_master_node():
        ar['DMFT_results']['iteration_count'] = it
        ar['DMFT_results']['Iterations']['Sigma_it'+str(it)] = S.Sigma_iw
        ar['DMFT_results']['Iterations']['Gloc_it'+str(it)] = S.G_iw
        ar['DMFT_results']['Iterations']['G0loc_it'+str(it)] = S.G0_iw
        ar['DMFT_results']['Iterations']['dc_imp'+str(it)] = SK.dc_imp
        ar['DMFT_results']['Iterations']['dc_energ'+str(it)] = SK.dc_energ
        ar['DMFT_results']['Iterations']['chemical_potential'+str(it)] = SK.chemical_potential

    #output the moment
    if mpi.is_master_node():
      up_den = 0
      dn_den = 0
      for j in range(0,5):
        mom = S.G_iw['up_'+str(j)].density()-S.G_iw['down_'+str(j)].density()
        up_den=up_den+S.G_iw['up_'+str(j)].density()
        dn_den=dn_den+S.G_iw['down_'+str(j)].density()
        mpi.report('density difference in the %s th orbital is = %s'%(j,mom))
      mpi.report('up density = %s'%up_den)
      mpi.report('down density = %s'%dn_den)
      mpi.report('tot moment = %s'%(up_den-dn_den))

#adnj edit - output the density matrix for Elk interface
dN, d = SK.calc_density_correction_elk()

#correlation energy via the Migdal formula
correnerg = 0.5 * (S.G_iw * S.Sigma_iw).total_density()

#subtract the double counting energy
correnerg -= SK.dc_energ[0]
#convert to Hartree
correnerg = correnerg/SK.energy_unit

#save the correction to energy
if (mpi.is_master_node()):
  f=open('DMATDMFT.OUT','a')
  f.write("%.16f\n"%correnerg)
  f.close()


